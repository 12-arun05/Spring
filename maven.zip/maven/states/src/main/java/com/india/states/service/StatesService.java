package com.india.states.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.india.states.dao.StatesDao;
import com.india.states.model.StatesModel;

@Service
public class StatesService {
	
	@Autowired
	StatesDao dao;
	
	public Iterable<StatesModel> getStateName() {
		return dao.findAll();
	}
	
	public Optional<StatesModel> searchStatesById(int stateId){
		return dao.findById(stateId);
	}
	
	public StatesModel addStates(StatesModel st) {
		StatesModel stM = dao.save(st);
		return stM;
	}
	
	public String deleteStates(int stateId) {
		dao.deleteById(stateId);
		return "The States deleted successfully... stateID: "+stateId;
	}
	
	public StatesModel updateStates(int stateId, String stateName) {
		StatesModel sm = new StatesModel(stateId, stateName);
		return dao.save(sm);
	}
}
