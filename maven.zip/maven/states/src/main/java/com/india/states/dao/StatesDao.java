package com.india.states.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.india.states.model.StatesModel;

@Repository
public interface StatesDao extends CrudRepository<StatesModel, Integer> {

}
