package com.india.states.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "States")
public class StatesModel {
	@Id
	private int stateId;
	@Column(name = "stateName")
	private String stateName;
	public StatesModel() {
		super();
	}
	public StatesModel(int stateId, String stateName) {
		super();
		this.stateId = stateId;
		this.stateName = stateName;
	}
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	@Override
	public String toString() {
		return "StatesModel [stateId=" + stateId + ", stateName=" + stateName + "]";
	}
	
	
}
