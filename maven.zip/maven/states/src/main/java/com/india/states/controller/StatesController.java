package com.india.states.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.india.states.model.StatesModel;
import com.india.states.service.StatesService;

@RestController
@RequestMapping("/states")
public class StatesController {
	public long visitorCount=0;
	
	@Autowired
	StatesService service;
	
	public StatesController() {
		System.err.println("State controller created...");
	}
	
	@RequestMapping(path="/")
	public ModelAndView home() {
		visitorCount++;
		ModelAndView mv = new ModelAndView("home");
		mv.addObject("visitorCount", visitorCount);
		return mv;
	}
	@GetMapping("/list")
	public ModelAndView getStatesList() {
		ModelAndView mv = new ModelAndView("listStates");
		mv.addObject("states", service.getStateName());
		return mv;
	}
	
	@GetMapping("/list/add")
	public ModelAndView addStates() {
		ModelAndView mv = new ModelAndView("addStates");
		return mv;
	}
	
	@PostMapping("/list/addState")
	public ModelAndView addedStates(@ModelAttribute StatesModel model) {
		ModelAndView mv = new ModelAndView("addedStates");
		StatesModel sm = service.addStates(model);
		mv.addObject("statesModel", sm);
		return mv;
		
	}
	
	@GetMapping("/list/delete")
	public ModelAndView deleteStates() {
		ModelAndView mv = new ModelAndView("deleteStates");
		return mv;
	}
	
	@PostMapping("/list/deletedState")
	public ModelAndView deletedStates(@RequestParam("stateId") int stateId) {
		ModelAndView mv = new ModelAndView("deletedStates");
		String sm = service.deleteStates(stateId);
		mv.addObject(sm);
		return mv;
	}
	@GetMapping("/list/update")
	public ModelAndView updateStates() {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
	@PostMapping("/list/updatedStates")
	public ModelAndView updatedStates(@RequestParam("stateId") int stateId, @RequestParam("stateName") String stateName) {
		ModelAndView mv = new ModelAndView("updateStates");
		StatesModel sm = service.updateStates(stateId, stateName);
		mv.addObject(sm);
		return mv;
	}

}
