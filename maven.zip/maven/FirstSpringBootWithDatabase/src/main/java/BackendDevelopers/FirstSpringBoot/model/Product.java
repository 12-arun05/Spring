package BackendDevelopers.FirstSpringBoot.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

//Linking this POJO class to the table in the database.
@Entity
@Table(name = "Product")
public class Product {
	
	@Id		// In the database this column is primary key
//	@GeneratedValue(strategy = GenerationType.AUTO) 	// for generating primary key values automatically
	private int productID;
	@Column(name = "productName") 	// link proudctName variable with productName column in the database.
	private String productName;
	
	
	public Product() {
		super();
		System.out.println("NEw Product created");
	}
	
	public Product(int productID, String productName) {
		super();
		this.productID = productID;
		this.productName = productName;
	}
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	@Override
	public String toString() {
		return "Product [productID=" + productID + ", productName=" + productName + "]";
	}

}
