package BackendDevelopers.FirstSpringBoot.dao;

import java.beans.JavaBean;
import java.util.HashMap;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import BackendDevelopers.FirstSpringBoot.model.Product;

@Repository
public interface ProductsList extends CrudRepository<Product, Integer> {
	//CrudRepository <Product, Integer> --Product is the data that will inserted into the database or retrieved from the database. Integer is the data type of the primary key.
	//to make our DAO for connection to the database. CrudRepository<Product, Integer> - Integer is the data type of the primary key in the database.
}
