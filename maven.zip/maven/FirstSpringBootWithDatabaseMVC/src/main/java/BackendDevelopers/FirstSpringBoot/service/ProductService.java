package BackendDevelopers.FirstSpringBoot.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import BackendDevelopers.FirstSpringBoot.dao.ProductsList;
import BackendDevelopers.FirstSpringBoot.model.Product;

//Any class marked with @Service controls concurrent or parallel access to the DAO layer, there by preventing data loss or data ambiguity or data corruption.
//@Service automatically create 

@Service
public class ProductService {
	
	@Autowired
	ProductsList pList;

	public ArrayList<Product> getProductsList(){
		System.out.println("Getting products list...");
		/*When you call findAll() method in the repository, it executes a SQL SELECT * from Products statement on the database.*/
		return (ArrayList<Product>) pList.findAll();
	}
	
	public Product addProduct(Product p) {
		System.out.println("Add the product...");
		Product t = pList.save(p);// save method convert into SQL insert statement.
		return t;
	}
	
	public String deleteProduct(int productID) {
		System.out.println("Delete the product");
		//When deleteById() is called, it convert this into SQL DELETE form Product where productId = productID
		pList.deleteById(productID);
		return "<b>Deleted product with ID </b>"+ productID;
	}
	
	public String searchProduct(int productID) {
		System.out.println("Search the product");
		//If productID is 4, this is converted to SQL - SELECT * from Products where productID =4
		Optional<Product> opt = pList.findById(productID);
		return "<b>Product found with ID: "+productID+" </b>"+ opt.get().toString() ;
	}
	
	public String updateProduct(int productID, String newProductName) {
		System.out.println("Update the product");
		Product d = new Product(productID, newProductName);
		//When save() method is called, if any product with given productId is existing, it updates productName with new ProductName. Otherwise it inserts a new record.
		
		return pList.save(d).toString();
	}
	
}
