package BackendDevelopers.FirstSpringBoot.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import BackendDevelopers.FirstSpringBoot.model.Product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;
import jakarta.websocket.server.PathParam;
 	 	 	
@RestController
@RequestMapping("/shopping")
public class Shopping {
	private static final String String = null;

	public long vistorCount = 0;
	
	/*Creates an object for ProductService class automatically. So, that becomes a bean. That bean is 
	 * injected into the controller(Shopping). This an example of dependency injection mechanism. Autowiring is
	 *  a type of dependency injection mechanism. */
	
	@Autowired
	ProductService service;
	
	public Shopping() {
		System.err.println("Shopping controller created...");
	}
	
	
	//link this api with the browser...
	//If the url is http://localhose:9080/shopping/
	
	@RequestMapping(path="/", method= RequestMethod.GET)
	public ModelAndView home() {
		vistorCount++;
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		mv.addObject("visCount", vistorCount);
	
		return mv;
	}

	@GetMapping("/list")
	public ModelAndView getProductsList(){
		ModelAndView mv = new ModelAndView();
		mv.setViewName("listProduct"); // Mention the name of the view(HTML file) to be displayed.
		mv.addObject("products",service.getProductsList()); //Attaching(binding) the model(data) with the view.
		return mv;
	}
	
	
	@GetMapping("/list/add")
	public ModelAndView addP() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addProduct");
		mv.addObject("Today",new java.util.Date().toString());
		vistorCount++;
		mv.addObject("vCount", vistorCount);
		return mv;
	}
	
	@PostMapping(path="/list/addProduct")
	public ModelAndView addProduct(@ModelAttribute Product p) {
		ModelAndView mv = new ModelAndView();
		Product t = service.addProduct(p);
		mv.setViewName("addedproduct");
		mv.addObject("product",t);// this is the name of the view(Html page) that has to be shown in the browser.
		return mv;
	}
	
	//@DeleteMapping is used to handle http DELETE request. IF DELETE request is sent, then deleteProduct() method is called to delete the product.
	//@REquestBody is used when the client sends data from a HTML form using either POST request or PUT request or  DELETE request or UPDATE request.
	@GetMapping("/list/delete")
	public ModelAndView delete() {
		 ModelAndView mv = new ModelAndView();
		 mv.setViewName("deleteProduct"); // show the same product list page
		 mv.addObject("products", service.getProductsList()); // refresh the list
		 mv.addObject("message", "The Product was deleted..."); // show success message
		 return mv;
	}
	@PostMapping("/list/deleteProduct")
	public ModelAndView deleteProduct(@RequestParam("productID") int productID) {
	    String message = service.deleteProduct(productID);
	    ModelAndView mv = new ModelAndView("deletedProduct");
	    mv.addObject("message", "Product ID " + productID + " deleted successfully.");
	    mv.addObject("products", service.getProductsList());
	    return mv;
	}
	 
	@GetMapping("/list/update")
	public ModelAndView showUpdateForm() {
	    ModelAndView mv = new ModelAndView("updateProduct");
	    mv.addObject("products", service.getProductsList());
	    mv.addObject("Today", new java.util.Date().toString());
	    mv.addObject("message", "Update an existing product");
	    return mv;
	}

	@PostMapping("/list/updatedProduct")
	public ModelAndView updateProduct(@RequestParam("productID") int productID,
	                                  @RequestParam("productName") String productName) {
		String updated = service.updateProduct(productID, productName);
	    ModelAndView mv = new ModelAndView("updatedProduct");
	    mv.addObject("product", updated);
	    mv.addObject("products", service.getProductsList());
	    mv.addObject("message", "Product updated successfully!");
	    return mv;
	}

	//@RequestParam indicates that the value for productID is sent at the end of the URL
		@GetMapping("list/search")
		public ModelAndView searchProduct(@RequestParam("productID") int productID) {
			ModelAndView mv = new ModelAndView("searchProduct");
			mv.addObject("search", service.searchProduct(productID));
			return mv;
			
		}
		
		@PostMapping("/list/searchProduct")
		public ModelAndView searchedProduct(@RequestParam("productID") int productID) {
			String searched = service.searchProduct(productID);
		    ModelAndView mv = new ModelAndView("updatedProduct");
		    mv.addObject("product", searched);
		    mv.addObject("products", service.getProductsList());
		    mv.addObject("message", "Product Searched successfully!");
		    return mv;
		}


	
	
	
}
