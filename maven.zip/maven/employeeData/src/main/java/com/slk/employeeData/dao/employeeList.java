package com.slk.employeeData.dao;

import org.springframework.data.repository.CrudRepository;
import com.slk.employeeData.model.Employee;

public interface employeeList extends CrudRepository<Employee, Integer> {

}
