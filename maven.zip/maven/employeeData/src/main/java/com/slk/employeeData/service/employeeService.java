package com.slk.employeeData.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.employeeData.dao.employeeList;
import com.slk.employeeData.model.Employee;
@Service
public class employeeService {
	
	@Autowired
	employeeList empList;
	
	public Iterable<Employee> getEmpList() {
		return empList.findAll();
	}
	
	public Optional<Employee> searchEmp(int empId) {
		return empList.findById(empId);
	}
	
	public String deleteEmp(int empId) {
		empList.deleteById(empId);
		return empId +" is deleted";
	}
	
	public Employee addEmp(Employee e) {
		return empList.save(e);
	}
	
	public String updateEmp(int empId, String newEmpName) {
		Employee newEmp = new Employee();
		return empList.save(newEmp).toString();
	}
}
