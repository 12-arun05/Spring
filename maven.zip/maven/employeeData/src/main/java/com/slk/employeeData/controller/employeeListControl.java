package com.slk.employeeData.controller;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.slk.employeeData.model.Employee;
import com.slk.employeeData.service.employeeService;

@RestController
@RequestMapping("/slk")
public class employeeListControl {
	
	@Autowired
	employeeService empService;
	
	@GetMapping("/")
	public String home() {
		String data = "<html><body><center><h1>";
		data += "Welcome to SLK Employee Portal</h1><br></center>";
		data +="</body></html>";
		return data;
	}
	
	@RequestMapping(path="/list", method = RequestMethod.GET)
	public ArrayList<Employee> getEmpList(){
		return (ArrayList<Employee>) empService.getEmpList();
	}
	
	@GetMapping("/list/search")
	public Optional<Employee> searchEmp(@RequestBody int empId) {
		return empService.searchEmp(empId);
	}
	
	@DeleteMapping("/list/delete")
	public String deleteEmp(@RequestBody int empId) {
		return empService.deleteEmp(empId);
	}
	
	@PostMapping("/list/add")
	public Employee addEmp(@RequestBody Employee e) {
		return empService.addEmp(e);
	}
	@PutMapping("/list/update")
	public String updateEmp(@RequestBody int empId, String empName) {
		return empService.updateEmp(empId,empName);
	}
}
