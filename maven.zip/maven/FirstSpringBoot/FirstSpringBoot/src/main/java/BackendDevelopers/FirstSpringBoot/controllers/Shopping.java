package BackendDevelopers.FirstSpringBoot.controllers;

import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import BackendDevelopers.FirstSpringBoot.model.Product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;
import jakarta.websocket.server.PathParam;
 	 	 	
@RestController
@RequestMapping("/shopping")
public class Shopping {
	public long vistorCount = 0;
	
	@Autowired
	ProductService service;
	
	public Shopping() {
		System.err.println("Shopping controller created...");
	}
	
	
	//link this api with the browser...
	//If the url is http://localhose:9080/shopping/
	
	@RequestMapping(path="/", method= RequestMethod.GET)
	public String home() {
		String response = "<html><body><center><h1>";
		response += "Welcome to online shopping</h1><br></center>";
		response += "<b>Your are visitor # "+vistorCount++;
		response +="</body></html>";
		return response.toString();
	}

	@GetMapping("/list")
//	@RequestMapping(path="/list", method = RequestMethod.GET)
	public HashMap<Integer, Product> getProductsList(){
			return service.getProductsList();
	}
	
	//@RequestParam indicates that the value for productID is sent at the end of the URL
	@GetMapping("list/search")
	public String searchProduct(@RequestParam("pID") int productID) {
		
		return service.searchProduct(productID);
		
	}
	
	//@DeleteMapping is used to handle http DELETE request. IF DELETE request is sent, then deleteProduct() method is called to delete the product.
	//@REquestBody is used when the client sends data from a HTML form using either POST request or PUT request or  DELETE request or UPDATE request.
	
	@DeleteMapping("/list/deleteID/{pID}")
	public String deleteProduct(@PathVariable("pID") int productID) {
		System.out.println("request got..");
		return service.deleteProduct(productID);
		
	}
	
	@PutMapping(path ="/list/update", consumes= MediaType.APPLICATION_JSON_VALUE)
	public String updateProduct(@RequestBody Product p) {
		return service.updateProduct(p.getProductID(), p.getProductName());
			
	}
	
	@PostMapping(path="/list/add", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String addProduct(@RequestBody Product p) {
		return service.addProduct(p);
	}
	
	
}
