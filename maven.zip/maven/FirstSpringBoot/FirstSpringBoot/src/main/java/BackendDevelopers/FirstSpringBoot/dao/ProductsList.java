package BackendDevelopers.FirstSpringBoot.dao;

import java.beans.JavaBean;
import java.util.HashMap;
import BackendDevelopers.FirstSpringBoot.model.Product;

@JavaBean
public class ProductsList {
	public HashMap<Integer, Product> productsList = new HashMap<>();
	
	public ProductsList() {
		productsList.put(1,new Product(1, "S25 Ultra"));
		productsList.put(2,new Product(2, "IPhone 17 pro Max"));
		productsList.put(3,new Product(3, "Samsung Z Fold"));
		productsList.put(4,new Product(4, "IMac"));
		productsList.put(5,new Product(5, "Realme P1 5g"));
		productsList.put(6,new Product(6, "Samsung smart watch 5"));
		System.err.println("Product list is created...");
	}
	
	public HashMap<Integer, Product> getProductsList(){
		System.out.println("Retrieved products list and sent it...");
		return productsList;
	}
	
	public String addProduct(Product p) {
		productsList.put(p.getProductID(),p);
		
		//it prints a log message
		System.err.println("Added a new product...");
		return "<b>Product added successfully. "+"Use /list to get updated list of products... </b>";
	}
	
	public String deleteProduct(int productID) {
		Product p = productsList.get(productID);
		if(p!= null)
			return "<b>This "+productsList.remove(productID)+ " is deleted...";
		else
			return "<b>Product not found</b>";
	}
	
	public String searchProduct(int productID) {
		Product p = productsList.get(productID);
		if(p!= null)
			return "<b>Product Found</b>&nbsp: " +p;
		else
			return "<b>Product not found</b>";
	}
	
	public String updateProduct(int productID, String newProductName) {
		Product p = productsList.get(productID);
		if(p!=null) {
			p.setProductName(newProductName);
			return "<b>Product found and update. Use /list to get the updated list</b>";
		}
		else
			return"<b>Product not found</b>";
	}

}
