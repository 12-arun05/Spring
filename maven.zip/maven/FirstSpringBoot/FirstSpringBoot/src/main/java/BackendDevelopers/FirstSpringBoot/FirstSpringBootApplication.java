package BackendDevelopers.FirstSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;

@SpringBootApplication
public class FirstSpringBootApplication {

	public static void main(String[] args) {
		//starts the tomcat server and deploys the website/application on the tomcat server.
		SpringApplication.run(FirstSpringBootApplication.class, args);
		System.out.println("Started the server.......");
	}

}
