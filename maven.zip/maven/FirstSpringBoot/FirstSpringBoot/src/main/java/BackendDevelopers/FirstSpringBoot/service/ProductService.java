package BackendDevelopers.FirstSpringBoot.service;

import java.util.HashMap;
import org.springframework.stereotype.Service;

import BackendDevelopers.FirstSpringBoot.dao.ProductsList;
import BackendDevelopers.FirstSpringBoot.model.Product;

//Any class marked with @Service controls concurrent or parallel access to the DAO layer, there by preventing data loss or data ambiguity or data corruption.
//@Service automatically create 

@Service
public class ProductService {
	
	ProductsList pList = new ProductsList();

	public HashMap<Integer, Product> getProductsList(){
		System.out.println("Getting products list...");
		return pList.getProductsList();
	}
	
	public String addProduct(Product p) {
		System.out.println("Add the product...");
		return pList.addProduct(p);
	}
	
	public String deleteProduct(int productID) {
		System.out.println("Delete the product");
		return pList.deleteProduct(productID);
	}
	
	public String searchProduct(int productID) {
		System.out.println("Search the product");
		return pList.searchProduct(productID);
	}
	
	public String updateProduct(int productID, String newProductName) {
		System.out.println("Update the product");
		return pList.updateProduct(productID, newProductName);
	}
	
}
