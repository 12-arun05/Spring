package Cricket.IPL2025.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Team")
public class Team {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String teamID;
	@Column(name = "teamName")
	private String teamName;
	
	public Team() {
		super();
		System.out.println("New product created...");
	}
	

	public Team(String teamID, String teamName) {
		super();
		this.teamID = teamID;
		this.teamName = teamName;
		System.out.println("New product created using teamID and teamName...");
	}


	public String getTeamID() {
		return teamID;
	}

	public void setTeamID(String teamABB) {
		this.teamID = teamABB;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamFULL) {
		this.teamName = teamFULL;
	}

	@Override
	public String toString() {
		return "Team [teamID= " + teamID + ", teamName= " + teamName + ", hashCode= "+hashCode()+"]";
	}
	

}
