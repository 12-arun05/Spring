package Cricket.IPL2025.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import Cricket.IPL2025.dao.IPL2025TeamList;
import Cricket.IPL2025.model.Team;

@Service
public class TeamService {
	
public long vistorCount = 0;
	
	@Autowired
	IPL2025TeamList tList;
	
	public ArrayList<Team> getteamList(){
		System.out.println("Getting team list...");
		return (ArrayList<Team>) tList.findAll();
}
	public String searchTeam(String teamID) {
		System.out.println("Search the team...");
		Optional<Team> ser =tList.findById(teamID);
		return "<b>Product found with ID: </b>"+teamID +ser.toString();
		
	}
	
	public String deleteTeam(String teamID) {
		System.out.println("Delete the team...");
		tList.deleteById(teamID);
		return "<b>Deleted team with ID </b>"+teamID;
	}
	
	public String addTeam(Team t) {
		System.out.println("Add the team...");
		Team t1= tList.save(t);
		return "<b>Added team</b>"+ t1;
	}
	
	public String updateProduct(String teamID, String newTeamName) {
		System.out.println("Update the new team");
		Team newT = new Team(teamID, newTeamName);
		return "<b>New team updated....</b>"+tList.save(newT).toString();
		
	}
	
}
