package Cricket.IPL2025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ipl2025Application {

	public static void main(String[] args) {
		SpringApplication.run(Ipl2025Application.class, args);
	}

}
