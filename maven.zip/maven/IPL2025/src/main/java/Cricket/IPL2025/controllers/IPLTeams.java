package Cricket.IPL2025.controllers;


import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import Cricket.IPL2025.model.Team;
import Cricket.IPL2025.service.TeamService;
import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("/iplTeams")
public class IPLTeams {
	
	public long vistorCount = 0;
	
	@Autowired
	TeamService service;
	
	public IPLTeams() {
		System.err.println("IPL Team controller created...");
	}

	@RequestMapping(path="/", method= RequestMethod.GET)
	public String home() {
		String response = "<html><body><center><h1>";
		response += "Welcome to Indian Premier League</h1><br></center>";
		response += "<b>Your are visitor # "+vistorCount++;
		response +="</body></html>";
		return response;
	}
	
	@GetMapping(path="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ArrayList<Team> getTeamList(){
		return service.getteamList();
}
	@GetMapping("list/search")
	public String searchTeam(@RequestParam("tID") String teamID) {
		return service.searchTeam(teamID);
		
	}
	
	@DeleteMapping("list/delete/{tID}")
	public String deleteTeam(@PathVariable("tID") String teamID) {
		return service.deleteTeam(teamID);
	}
	
	
	@PostMapping(path="list/add", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String addProduct(@RequestBody Team t) {
		return service.addTeam(t);
	}
	
	@PutMapping(path="list/update", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String updateProduct(@RequestBody Team t) {
		return service.updateProduct(t.getTeamID(), t.getTeamName());
	}
	
	
}
