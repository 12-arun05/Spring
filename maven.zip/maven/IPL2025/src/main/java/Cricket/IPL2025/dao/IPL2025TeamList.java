package Cricket.IPL2025.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import Cricket.IPL2025.model.Team;

@Repository
public interface IPL2025TeamList extends CrudRepository<Team, String> {

//	Team deleteById(String teamID);

}
