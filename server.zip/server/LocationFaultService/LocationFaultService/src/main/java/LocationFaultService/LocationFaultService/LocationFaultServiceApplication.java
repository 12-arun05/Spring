package LocationFaultService.LocationFaultService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
/*This automatically configures Hystrix Server*/
@Configuration

/*This will start and configure Hystrix Dashboard. With Hystrix dashboard we know: -
 * How many instances are running ? On which machine, which port ?
 * Since how time they are running ?
 * Some more administrative information
 * Configuring Hystrix dashboard is optional
 * */
@org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard

/*This annotation makes this application as a Hystrix Server or Circuit-Breaker.
 * This annotation is must*/
@org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker
public class LocationFaultServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocationFaultServiceApplication.class, args);
	}
}
