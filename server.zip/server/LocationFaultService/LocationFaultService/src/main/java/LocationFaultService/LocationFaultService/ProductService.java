package LocationFaultService.LocationFaultService;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import BackendDevelopers.FirstSpringBoot.model.Product;

//The class containing the routing/false-tolerance logic must be marked as a service
@Service
public class ProductService {
	@Autowired
	RestTemplate  resttemp;
		
	//timeOutInMilliseconds means within that time, the instance @ port 9080 must respond.
	@HystrixCommand(fallbackMethod="pingAlternate_Fallback", commandProperties= 
		{@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="5000")})
	public  ArrayList<Product> getStoreInfo() {
		System.out.println("Trying to ping to localhost:9080");
		/*
		 * exchange(URL, RequestType, <parameters/null>, <ReturnType>)
		 */ 
		//if this call fails, then run the fallbackMethod
		ArrayList<Product> res=resttemp.getForObject("http://localhost:9080/shopping/list", ArrayList.class);
		System.out.println("Got the response from localhost:9080");
		return res;
	}
	//These methods are called fallbackMethod/callbackMethod. It is called 
	//automatically by Hystrix. Not explicitly.
	@HystrixCommand(fallbackMethod="mirror1_Fallback", commandProperties= 
		{@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="5000")})
	private ArrayList<Product> pingAlternate_Fallback()
	{
		System.out.println("Pinging to alternate @ 9081");
		ArrayList<Product> res=resttemp.getForObject("http://localhost:9081/shopping/list", ArrayList.class);
		System.out.println("Got the response from  server @ 9081...");
		return res;
	}
	
	private ArrayList<Product> mirror1_Fallback() {
		System.out.println("Pinging to alternate @ 9082");
		ArrayList<Product> res=resttemp.getForObject("http://localhost:9082/shopping/list", ArrayList.class);
		System.out.println("Got the response");
		return res;
	}
	//Customizing the bean creation.
	@Bean
	public RestTemplate  resttemp() {
		return  new RestTemplate();
	}
}
