package RibbonLoadBalancer.RibbonLoadBalancer;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import org.springframework.validation.annotation.Validated;

//POJO - Plain Old Java Object
/*A POJO class will have variables and for every variable, there will
 * be a pair of getter and setter methods. There must be a No-argument
 * contructor.
 */
public class Product {
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	
	@Override
	public String toString() {
		return "Product [productID=" + productID + ", productName=" + productName + "]";
	}

	@Range(min=10,max=99999,message="Value must be between 10 and 99,999")
	private int productID;
	
	@NotNull(message="ProductName is mandatory")
	private String productName;
	
	@Size(min=5, message="Distributor name must be minimum 5 characters")
	private String distributor;
}
